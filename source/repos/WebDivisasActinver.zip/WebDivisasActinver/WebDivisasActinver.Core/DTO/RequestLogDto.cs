﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WebDivisasActinver.Core.DTO
{
    public class RequestLogDto
    {
        public string? UserId { get; set; }
        public string Path { get; set; } = null!;
        public string Method { get; set; } = null!;
        public DateTime Timestamp { get; set; }
    }
}
