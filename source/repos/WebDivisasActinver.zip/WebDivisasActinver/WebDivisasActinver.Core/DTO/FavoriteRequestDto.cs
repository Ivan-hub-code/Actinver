﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WebDivisasActinver.Core.DTO
{
    public class FavoriteRequestDto
    {
        public string UserId { get; set; } = string.Empty;
        public string CurrencyCode { get; set; } = string.Empty;
    }
}
