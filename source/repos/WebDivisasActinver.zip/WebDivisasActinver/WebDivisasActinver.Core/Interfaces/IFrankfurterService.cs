﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WebDivisasActinver.Core.Interfaces
{
    public interface IFrankfurterService
    {
  
        Task<Dictionary<string, string>> GetCurrenciesAsync();

        Task<Dictionary<string, decimal>> GetLatestRatesAsync(string baseCurrency, IEnumerable<string> targetCurrencies);

        Task<Dictionary<string, decimal>> GetHistoricalRatesAsync(DateTime date, string baseCurrency, IEnumerable<string> targetCurrencies);
    }
}
