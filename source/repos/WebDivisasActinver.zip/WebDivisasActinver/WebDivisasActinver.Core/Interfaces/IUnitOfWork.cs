﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WebDivisasActinver.Core.Models;

namespace WebDivisasActinver.Core.Interfaces
{
    public interface IUnitOfWork
    {
        IGenericRepository<FavoriteCurrency> Favorites { get; }
        IGenericRepository<Currency> Currencies { get; }
        Task<int> CompleteAsync();
        void Dispose();
    }
}
