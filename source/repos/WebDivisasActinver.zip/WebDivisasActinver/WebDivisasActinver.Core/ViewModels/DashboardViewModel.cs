﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WebDivisasActinver.Core.ViewModels
{
    public class DashboardViewModel
    {
        public string BaseCurrency { get; set; } = "USD";
        public List<string> FavoriteCurrencies { get; set; } = new();
        public Dictionary<string, decimal> Rates { get; set; } = new();
        public DateTime SelectedDate { get; set; } = DateTime.UtcNow.Date;
        public decimal Amount { get; set; } = 1m;
        public Dictionary<string, decimal> Converted { get; set; } = new();
        public string Message { get; set; } = string.Empty;
    }
}
