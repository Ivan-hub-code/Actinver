﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WebDivisasActinver.Core.Models
{
    public class Currency
    {
        public int Id { get; set; }
        public string Code { get; set; } = null!; 
        public string Name { get; set; } = null!;
        public bool IsFavorite { get; set; }
        public bool IsMain { get; set; }
    }
}
