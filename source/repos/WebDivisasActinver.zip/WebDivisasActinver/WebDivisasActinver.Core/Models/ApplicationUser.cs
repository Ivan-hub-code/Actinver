﻿using Microsoft.AspNetCore.Identity;

namespace WebDivisasActinver.Core.Models
{
    public class ApplicationUser : IdentityUser
    {
        // Campos adicionales opcionales
        public string FullName { get; set; }
    }
}
