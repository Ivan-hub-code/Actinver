﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WebDivisasActinver.Core.Models
{
    public class FavoriteCurrency
    {
        public int Id { get; set; }
        public string? UserId { get; set; }  
        public string CurrencyCode { get; set; } = null!;
        public bool IsActive { get; set; } = true;

        public int? ExchangeRateHistoryId { get; set; }  
    }
}
