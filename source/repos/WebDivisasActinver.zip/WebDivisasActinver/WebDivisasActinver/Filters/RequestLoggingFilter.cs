﻿using Microsoft.AspNetCore.Mvc.Filters;
using System.Security.Claims;
using WebDivisasActinver.Core.Interfaces;
using WebDivisasActinver.Core.Models;
using WebDivisasActinver.Infrastructure.Data;

namespace WebDivisasActinver.Filters
{

    public class RequestLoggingFilter : IAsyncActionFilter
    {
        private readonly IGenericRepository<RequestLog> _requestLogRepo;
        public RequestLoggingFilter(IGenericRepository<RequestLog> requestLogRepo)
        {
            _requestLogRepo = requestLogRepo;
        }
        public async Task OnActionExecutionAsync(ActionExecutingContext context, ActionExecutionDelegate next)
        {
            try
            {
                var request = context.HttpContext.Request;

                var log = new RequestLog
                {
                    UserId = context.HttpContext.User.FindFirst(ClaimTypes.NameIdentifier)?.Value,
                    Path = request.Path,
                    Method = request.Method,
                    Timestamp = DateTime.UtcNow
                };

                await _requestLogRepo.AddAsync(log);
                await _requestLogRepo.SaveAsync();
            }
            catch
            {
                // No bloquear la petición si hay error
            }

            await next();
        }
    }
}
