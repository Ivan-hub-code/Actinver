﻿document.addEventListener("DOMContentLoaded", function () {

    const baseCurrencyElem = document.getElementById("baseCurrency");
    const dateInput = document.getElementById("dateInput");
    const amountInput = document.getElementById("amountInput");
    const updateBtn = document.getElementById("updateBtn");
    const messageDiv = document.getElementById("message");
    const ratesTableBody = document.querySelector("#ratesTable tbody");

    const userId = document.getElementById("UserId").value;


    // Inicializar fecha
    dateInput.value = new Date().toISOString().split('T')[0];

    async function fetchRates(date, amount) {
        messageDiv.style.display = "none";
        messageDiv.textContent = "";
        ratesTableBody.innerHTML = "";

        try {
            const params = new URLSearchParams({ date, amount });
            const response = await fetch(`/Dashboard/GetRates?${params}`);
            const data = await response.json();

            if (data.success) {
                baseCurrencyElem.textContent = data.baseCurrency;

                if (data.rates && Object.keys(data.rates).length > 0) {
                    for (const [currency, rate] of Object.entries(data.rates)) {
                        const converted = (data.converted[currency] || 0).toFixed(2);
                        const tr = document.createElement("tr");
                        tr.innerHTML = `<td>${currency}</td><td>${rate.toFixed(4)}</td><td>${converted}</td>`;
                        ratesTableBody.appendChild(tr);
                    }
                } else {
                    messageDiv.style.display = "block";
                    messageDiv.textContent = "No se encontraron tasas para las monedas favoritas.";
                }

            } else {
                messageDiv.style.display = "block";
                messageDiv.textContent = data.message;
            }

        } catch (error) {
            messageDiv.style.display = "block";
            messageDiv.textContent = "Error al obtener las tasas de cambio.";
            console.error(error);
        }
    }

    updateBtn.addEventListener("click", () => {
        const date = dateInput.value;
        const amount = parseFloat(amountInput.value);
        if (date && amount > 0) {
            fetchRates(date, amount);
        } else {
            messageDiv.style.display = "block";
            messageDiv.textContent = "Por favor, ingrese una fecha válida y un monto mayor a cero.";
        }
    });


    fetchRates(dateInput.value, parseFloat(amountInput.value));
});