﻿const loginForm = document.getElementById("loginForm");

loginForm.addEventListener("submit", async (e) => {
    e.preventDefault();

    const email = document.getElementById("email").value;
    const password = document.getElementById("password").value;
    debugger;
    try {
        const res = await fetch("/Account/Login", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ Email: email, Password: password }) 
        });

        if (!res.ok) {
            const error = await res.json();
            alert(error.message);
            return;
        }

        const data = await res.json();
        // Redirecciona al dashboard
        window.location.href = data.redirectUrl;

    } catch (err) {
        console.error(err);
        alert("Ocurrió un error en el login");
    }
});