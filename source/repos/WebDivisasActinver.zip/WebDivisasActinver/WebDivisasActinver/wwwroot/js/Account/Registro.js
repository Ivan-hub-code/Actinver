﻿document.getElementById("registerForm").addEventListener("submit", async (e) => {
    e.preventDefault();

    const data = {
        fullName: document.getElementById("fullName").value,
        email: document.getElementById("email").value,
        password: document.getElementById("password").value,
        confirmPassword: document.getElementById("confirmPassword").value
    };

    const messageBox = document.getElementById("registerMessage");

    try {
        const res = await fetch("/Account/Register", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify(data)
        });

        const result = await res.json();
        if (res.ok) {
            showAlert(result.message, "success"); 
            setTimeout(() => window.location.href = "/", 2000);
        } else {
            const errors = Array.isArray(result)
                ? result.map(e => e.description).join("<br>")
                : result.message;

            showAlert(errors, "danger"); 
        }

    } catch (err) {
        console.error("Error en registro:", err);
        if (messageBox) {
            messageBox.style.color = "red";
            messageBox.innerText = "Error en la conexión con el servidor.";
        }
    }
});


function showAlert(message, type = "danger", timeout = 4000) {
    const container = document.getElementById("alertContainer");

    const alert = document.createElement("div");
    alert.className = `alert alert-${type} alert-dismissible fade show`;
    alert.role = "alert";
    alert.innerHTML = `
        ${message}
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    `;

    container.appendChild(alert);

    setTimeout(() => {
        alert.classList.remove("show");
        alert.classList.add("fade");
        setTimeout(() => alert.remove(), 1000);
    }, timeout);
}