﻿document.addEventListener("DOMContentLoaded", function () {
    const sidebar = document.getElementById("sidebar");
    const content = document.getElementById("page-content-wrapper");
    const toggles = document.querySelectorAll("#sidebarToggle, #sidebarToggleMobile");

    toggles.forEach(btn => {
        btn.addEventListener("click", function () {
            sidebar.classList.toggle("collapsed");
            content.classList.toggle("collapsed");
        });
    });
});

document.getElementById("logoutBtn").addEventListener("click", async () => {
    try {
        const res = await fetch("/Account/Logout", { method: "POST" });

        if (res.ok) {
            // Redirigir al login o inicio
            window.location.href = "/";
        } else {
            alert("Error al cerrar sesión");
        }
    } catch (err) {
        console.error(err);
        alert("Error al cerrar sesión");
    }
});