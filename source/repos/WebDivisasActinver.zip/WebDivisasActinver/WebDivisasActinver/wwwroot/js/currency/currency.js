﻿document.addEventListener("DOMContentLoaded", async () => {
    const userId = document.getElementById("UserId").value; // Se obtiene del input hidden
    const container = document.getElementById("currenciesContainer");

    async function loadCurrencies() {
        try {
            const response = await fetch(`/Currency/GetDivisas?userId=${userId}`);
            const data = await response.json();
            renderCurrencies(data);
        } catch (err) {
            console.error("Error al cargar monedas:", err);
        }
    }

    function renderCurrencies(currencies) {
        container.innerHTML = "";
        currencies.forEach(c => {
            const col = document.createElement("div");
            col.className = "col";

            const card = document.createElement("div");
            card.className = `card h-100 ${c.isFavorite ? "border-success" : ""}`;
            card.dataset.code = c.code;

            const body = document.createElement("div");
            body.className = "card-body";

            const title = document.createElement("h5");
            title.className = "card-title";
            title.textContent = `${c.code} - ${c.name}`;
            body.appendChild(title);

            if (c.isMain) {
                const badge = document.createElement("span");
                badge.className = "badge bg-primary";
                badge.textContent = "Moneda principal";
                body.appendChild(badge);
            }

            const divBtn = document.createElement("div");
            divBtn.className = "mt-3";

            // Botones favoritos
            const addBtn = document.createElement("button");
            addBtn.className = "btn btn-sm btn-outline-success me-2";
            addBtn.textContent = "Agregar a favoritas";
            addBtn.style.display = c.isFavorite ? "none" : "inline-block";
            addBtn.addEventListener("click", () => toggleFavorite(c.code, "add", card, addBtn, removeBtn));

            const removeBtn = document.createElement("button");
            removeBtn.className = "btn btn-sm btn-outline-danger me-2";
            removeBtn.textContent = "Quitar de favoritas";
            removeBtn.style.display = c.isFavorite ? "inline-block" : "none";
            removeBtn.addEventListener("click", () => toggleFavorite(c.code, "remove", card, addBtn, removeBtn));

            divBtn.appendChild(addBtn);
            divBtn.appendChild(removeBtn);

            // Botón principal
            const mainBtn = document.createElement("button");
            mainBtn.className = "btn btn-sm btn-outline-primary";
            mainBtn.textContent = "Seleccionar como principal";
            mainBtn.style.display = c.isMain ? "none" : "inline-block";
            mainBtn.addEventListener("click", () => setMain(c.code, card, mainBtn));

            divBtn.appendChild(mainBtn);

            body.appendChild(divBtn);
            card.appendChild(body);
            col.appendChild(card);
            container.appendChild(col);
        });
    }

    async function toggleFavorite(code, action, card, addBtn, removeBtn) {
        try {
            const res = await fetch(`/Currency/${action === "add" ? "AddFavorite" : "RemoveFavorite"}`, {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify({ userId, currencyCode: code })
            });
            if (res.ok) {
                addBtn.style.display = action === "add" ? "none" : "inline-block";
                removeBtn.style.display = action === "remove" ? "none" : "inline-block";
                card.classList.toggle("border-success");
            }
        } catch (err) {
            console.error("Error al actualizar favorita:", err);
        }
    }

    async function setMain(code, card, mainBtn) {
        try {
            const res = await fetch("/Currency/SetMain", {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify({ userId, currencyCode: code })
            });
            if (res.ok) {
                document.querySelectorAll(".badge.bg-primary").forEach(b => b.remove());
                document.querySelectorAll(".btn-outline-primary").forEach(b => b.style.display = "inline-block");

                const badge = document.createElement("span");
                badge.className = "badge bg-primary";
                badge.textContent = "Moneda principal";
                card.querySelector(".card-body").prepend(badge);

                mainBtn.style.display = "none";
            }
        } catch (err) {
            console.error("Error al seleccionar moneda principal:", err);
        }
    }

    loadCurrencies();
});
