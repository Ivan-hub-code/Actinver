﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using WebDivisasActinver.Core.DTO;
using WebDivisasActinver.Core.Interfaces;
using WebDivisasActinver.Core.Models;

namespace WebDivisasActinver.Controllers
{
    [Authorize]
    public class CurrencyController : Controller
    {
        private readonly IFrankfurterService _exchangeService;
        private readonly IGenericRepository<FavoriteCurrency> _favoriteRepo;
        private readonly IGenericRepository<MainCurrency> _mainRepo;

        public CurrencyController(IFrankfurterService exchangeService,IGenericRepository<FavoriteCurrency> favoriteRepo,IGenericRepository<MainCurrency> mainRepo)
        {
            _exchangeService = exchangeService;
            _favoriteRepo = favoriteRepo;
            _mainRepo = mainRepo;
        }

        public IActionResult Manage() => View();

        [HttpGet]
        public async Task<IActionResult> GetDivisas(string userId)
        {
            var allCurrencies = await _exchangeService.GetCurrenciesAsync();

            var favorites = (await _favoriteRepo.GetAllAsync())
                                .Where(f => f.UserId == userId)
                                .ToList();

            var mainCurrency = (await _mainRepo.GetAllAsync())
                                .FirstOrDefault(m => m.UserId == userId);

            var model = allCurrencies.Select(c => new CurrencyDto
            {
                Code = c.Key,
                Name = c.Value,
                IsFavorite = favorites.Any(f => f.CurrencyCode == c.Key),
                IsMain = mainCurrency?.CurrencyCode == c.Key
            })
            .OrderBy(c => c.Code)
            .ToList();

            return Json(model);
        }

        [HttpPost]
        public async Task<IActionResult> AddFavorite([FromBody] FavoriteRequestDto request)
        {
            if (request == null) return BadRequest();

            await _favoriteRepo.AddAsync(new FavoriteCurrency
            {
                UserId = request.UserId,
                CurrencyCode = request.CurrencyCode
            });
            await _favoriteRepo.SaveAsync();

            return Ok();
        }

        [HttpPost]
        public async Task<IActionResult> RemoveFavorite([FromBody] FavoriteRequestDto request)
        {
            if (request == null) return BadRequest();

            var favorite = (await _favoriteRepo.GetAllAsync())
                            .FirstOrDefault(f => f.UserId == request.UserId && f.CurrencyCode == request.CurrencyCode);

            if (favorite != null)
            {
                _favoriteRepo.Remove(favorite);
                await _favoriteRepo.SaveAsync();
            }

            return Ok();
        }

        [HttpPost]
        public async Task<IActionResult> SetMain([FromBody] FavoriteRequestDto request)
        {
            var main = (await _mainRepo.GetAllAsync())
                        .FirstOrDefault(m => m.UserId == request.UserId);

            if (main != null)
            {
                main.CurrencyCode = request.CurrencyCode;
                _mainRepo.Update(main);
            }
            else
            {
                await _mainRepo.AddAsync(new MainCurrency
                {
                    UserId = request.UserId,
                    CurrencyCode = request.CurrencyCode
                });
            }

            await _mainRepo.SaveAsync();
            return Ok();
        }

        public IActionResult Index() => View();
    }
}
