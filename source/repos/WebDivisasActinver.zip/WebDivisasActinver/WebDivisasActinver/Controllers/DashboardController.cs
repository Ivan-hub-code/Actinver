﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System.Security.Claims;
using WebDivisasActinver.Core.Interfaces;
using WebDivisasActinver.Core.Models;
using WebDivisasActinver.Core.ViewModels;

namespace WebDivisasActinver.Controllers
{
    [Authorize]
    public class DashboardController : Controller
    {
        private readonly IFrankfurterService _api;
        private readonly IGenericRepository<FavoriteCurrency> _favoriteRepo;
        private readonly IGenericRepository<MainCurrency> _mainRepo;

        public DashboardController(
            IFrankfurterService api,
            IGenericRepository<FavoriteCurrency> favoriteRepo,
            IGenericRepository<MainCurrency> mainRepo)
        {
            _api = api;
            _favoriteRepo = favoriteRepo;
            _mainRepo = mainRepo;
        }

        [HttpGet]
        public async Task<IActionResult> GetRates(string baseCurrency = null, DateTime? date = null, decimal amount = 1m)
        {
            // Obtener el UserId del usuario autenticado
            var currentUserId = User.FindFirst(ClaimTypes.NameIdentifier)?.Value;
            if (currentUserId == null)
            {
                return Unauthorized(new { success = false, message = "Usuario no autenticado." });
            }

            var vm = new DashboardViewModel
            {
                SelectedDate = date ?? DateTime.UtcNow.Date,
                Amount = amount
            };

            // Moneda principal asociada al usuario
            var mainCurrency = (await _mainRepo.GetAllAsync())
                                .FirstOrDefault(m => m.UserId == currentUserId);

            vm.BaseCurrency = mainCurrency?.CurrencyCode ?? "USD";

            // Favoritos del usuario
            var favorites = (await _favoriteRepo.GetAllAsync())
                                .Where(f => f.UserId == currentUserId)
                                .Select(f => f.CurrencyCode)
                                .ToList();

            if (!favorites.Any())
            {
                return Json(new { success = false, message = "No tienes monedas favoritas registradas." });
            }

            vm.FavoriteCurrencies = favorites;

            // Obtener tasas desde la API
            vm.Rates = (date == null)
                ? await _api.GetLatestRatesAsync(vm.BaseCurrency, favorites)
                : await _api.GetHistoricalRatesAsync(vm.SelectedDate, vm.BaseCurrency, favorites);

            // Conversiones
            vm.Converted = vm.Rates.ToDictionary(
                kv => kv.Key,
                kv => Math.Round(kv.Value * amount, 4)
            );

            return Json(new
            {
                success = true,
                baseCurrency = vm.BaseCurrency,
                favorites = vm.FavoriteCurrencies,
                rates = vm.Rates,
                converted = vm.Converted
            });
        }


        public IActionResult Index()
        {
            return View();
        }




    }
}
