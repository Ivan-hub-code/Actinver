﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using WebDivisasActinver.Core.DTO;
using WebDivisasActinver.Infrastructure.Data;

namespace WebDivisasActinver.Controllers
{
    [Authorize(Roles = "Admin")]
    public class LogsController : Controller
    {
        private readonly ExchangeDbContext _db;

        public LogsController(ExchangeDbContext db)
        {
            _db = db;
        }

        public IActionResult Index()
        {
            var logs = _db.RequestLogs
                .OrderByDescending(l => l.Timestamp)
                .Select(l => new RequestLogDto
                {
                    UserId = l.UserId,
                    Path = l.Path,
                    Method = l.Method,
                    Timestamp = l.Timestamp
                }).ToList();

            return View(logs);
        }


      
    }



}
