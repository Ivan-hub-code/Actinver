﻿using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using System.Security.Claims;
using WebDivisasActinver.Core.DTO;
using WebDivisasActinver.Core.Models;

namespace WebDivisasActinver.Controllers
{
    public class AccountController : Controller
    {
        private readonly UserManager<ApplicationUser> _userManager;
        private readonly SignInManager<ApplicationUser> _signInManager;

        public AccountController(UserManager<ApplicationUser> userManager,
                                 SignInManager<ApplicationUser> signInManager)
        {
            _userManager = userManager;
            _signInManager = signInManager;
        }

    
        [HttpGet]
        public IActionResult Register() => View();

        [HttpPost]
        public async Task<IActionResult> Register([FromBody] RegisterDto model)
        {
            if (!ModelState.IsValid)
                return BadRequest(new { message = "Datos inválidos." });

            if (model.Password != model.ConfirmPassword)
                return BadRequest(new { message = "Las contraseñas no coinciden." });

            var user = new ApplicationUser
            {
                UserName = model.Email,
                Email = model.Email,
                FullName = model.FullName
            };

            var result = await _userManager.CreateAsync(user, model.Password);

            if (!result.Succeeded)
            {
                var erroresTraducidos = result.Errors.Select(e => new
                {
                    code = e.Code,
                    description = TraducirError(e.Code)
                });
                return BadRequest(erroresTraducidos);
            }

            return Ok(new { message = "Usuario registrado con éxito." });
        }

        private string TraducirError(string code) => code switch
        {
            "PasswordRequiresNonAlphanumeric" => "La contraseña debe tener al menos un carácter especial.",
            "PasswordRequiresDigit" => "La contraseña debe contener al menos un número.",
            "PasswordRequiresLower" => "La contraseña debe contener al menos una letra minúscula.",
            "PasswordRequiresUpper" => "La contraseña debe contener al menos una letra mayúscula.",
            "PasswordTooShort" => "La contraseña es demasiado corta.",
            "DuplicateEmail" => "Este correo electrónico ya está registrado.",
            "DuplicateUserName" => "Este usuario ya existe.",
            _ => code
        };

        // GET: Login
        [HttpGet]
        public IActionResult Login(string? returnUrl = null)
        {
            ViewData["ReturnUrl"] = returnUrl;
            return View();
        }

        // POST: Login
        [HttpPost]
        public async Task<IActionResult> Login([FromBody] LoginDto model)
        {
            if (!ModelState.IsValid)
                return BadRequest(new { message = "Datos inválidos." });

            var user = await _userManager.FindByEmailAsync(model.Email);
            if (user == null || !await _userManager.CheckPasswordAsync(user, model.Password))
                return Unauthorized(new { message = "Usuario o contraseña incorrectos." });


            var roles = await _userManager.GetRolesAsync(user);



            var claims = new List<Claim>
            {
                new Claim(ClaimTypes.NameIdentifier, user.Id),
                new Claim(ClaimTypes.Name, user.FullName)
            };


            claims.AddRange(roles.Select(r => new Claim(ClaimTypes.Role, r)));

            var claimsIdentity = new ClaimsIdentity(claims, IdentityConstants.ApplicationScheme);

            var authProperties = new AuthenticationProperties
            {
                IsPersistent = false
            };

            await HttpContext.SignInAsync(
                IdentityConstants.ApplicationScheme,
                new ClaimsPrincipal(claimsIdentity),
                authProperties
            );

            return Ok(new { redirectUrl = Url.Action("Index", "Dashboard") });
        }

        // POST: Logout
        [HttpPost]
        public async Task<IActionResult> Logout()
        {
            await _signInManager.SignOutAsync();
            return Ok(new { message = "Sesión cerrada" });
        }

        // GET: Acceso Denegado
        [HttpGet]
        public IActionResult AccessDenied() => View();



        [Authorize(Roles = "Admin")]
        [HttpPost]
        public async Task<IActionResult> MakeAdmin([FromBody] string userEmail)
        {
            var user = await _userManager.FindByEmailAsync(userEmail);
            if (user == null)
                return NotFound(new { message = "Usuario no encontrado." });

            // Revisamos si ya es admin
            if (await _userManager.IsInRoleAsync(user, "Admin"))
                return BadRequest(new { message = "El usuario ya es administrador." });

            var result = await _userManager.AddToRoleAsync(user, "Admin");
            if (!result.Succeeded)
                return BadRequest(new { message = "No se pudo asignar el rol.", errors = result.Errors });

            return Ok(new { message = "Usuario ahora es administrador." });
        }


        [Authorize(Roles = "Admin")]
        [HttpGet]
        public async Task<IActionResult> GetAllUsers()
        {
            var users = _userManager.Users.ToList();
            var list = new List<object>();

            foreach (var u in users)
            {
                var roles = await _userManager.GetRolesAsync(u);
                list.Add(new { u.FullName, u.Email, roles });
            }

            return Json(list);
        }

        [Authorize(Roles = "Admin")]
        [HttpGet]
        public IActionResult AdminUsers()
        {
            return View();
        }

    }
}
