﻿using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;

using WebDivisasActinver.Core.Models;

namespace WebDivisasActinver.Infrastructure.Data
{
    public class ExchangeDbContext : IdentityDbContext<ApplicationUser>
    {
        public ExchangeDbContext(DbContextOptions<ExchangeDbContext> options)
            : base(options) { }

        // Tus tablas
        public DbSet<Currency> Currencies => Set<Currency>();
        public DbSet<FavoriteCurrency> FavoriteCurrencies => Set<FavoriteCurrency>();
        public DbSet<MainCurrency> MainCurrencies => Set<MainCurrency>();
        public DbSet<RequestLog> RequestLogs { get; set; }


        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            // Muy importante: llama al base para Identity
            base.OnModelCreating(modelBuilder);

            // Claves primarias
            modelBuilder.Entity<FavoriteCurrency>().HasKey(f => f.Id);
            modelBuilder.Entity<MainCurrency>().HasKey(m => m.Id);

            // Opcional: configuración adicional
            modelBuilder.Entity<Currency>().HasKey(c => c.Code);
        }
    }
}
