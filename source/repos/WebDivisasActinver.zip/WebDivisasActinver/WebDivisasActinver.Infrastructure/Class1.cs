﻿namespace WebDivisasActinver.Infrastructure
{
    public class Class1
    {

    }
}
