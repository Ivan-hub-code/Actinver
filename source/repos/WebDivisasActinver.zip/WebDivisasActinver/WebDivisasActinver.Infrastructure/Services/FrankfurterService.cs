﻿using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;
using WebDivisasActinver.Core.Interfaces;

namespace WebDivisasActinver.Infrastructure.Services
{
    public class FrankfurterService : ExchangeServiceBase, IFrankfurterService
    {
        public FrankfurterService(HttpClient client, ILogger<FrankfurterService> logger) : base(client, logger) { }

        public async Task<Dictionary<string, string>> GetCurrenciesAsync()
        {
            var json = await Client.GetStringAsync("currencies");
            using var doc = JsonDocument.Parse(json);
            var dict = new Dictionary<string, string>();
            foreach (var p in doc.RootElement.EnumerateObject()) dict[p.Name] = p.Value.GetString()!;
            return dict;
        }

        public async Task<Dictionary<string, decimal>> GetLatestRatesAsync(string from, IEnumerable<string> to)
        {
            var toParam = string.Join(",", to);
            var json = await Client.GetStringAsync($"latest?from={from}&to={toParam}");
            using var doc = JsonDocument.Parse(json);
            var rates = doc.RootElement.GetProperty("rates");
            var outd = new Dictionary<string, decimal>();
            foreach (var p in rates.EnumerateObject()) outd[p.Name] = p.Value.GetDecimal();
            return outd;
        }

        public async Task<Dictionary<string, decimal>> GetHistoricalRatesAsync(DateTime date, string from, IEnumerable<string> to)
        {
            var toParam = string.Join(",", to);
            var dateStr = date.ToString("yyyy-MM-dd");
            var json = await Client.GetStringAsync($"{dateStr}?from={from}&to={toParam}");
            using var doc = JsonDocument.Parse(json);
            var rates = doc.RootElement.GetProperty("rates");
            var outd = new Dictionary<string, decimal>();
            foreach (var p in rates.EnumerateObject()) outd[p.Name] = p.Value.GetDecimal();
            return outd;
        }
    }
}
