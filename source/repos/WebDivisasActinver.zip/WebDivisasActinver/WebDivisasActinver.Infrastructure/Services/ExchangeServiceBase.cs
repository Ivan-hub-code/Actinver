﻿using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;

namespace WebDivisasActinver.Infrastructure.Services
{
    public abstract class ExchangeServiceBase
    {
        protected readonly HttpClient Client;
        protected readonly ILogger _logger;
        protected ExchangeServiceBase(HttpClient client, ILogger logger)
        {
            Client = client; _logger = logger;
        }

        protected async Task<T> GetAsync<T>(string url)
        {
            var str = await Client.GetStringAsync(url);
            return JsonSerializer.Deserialize<T>(str, new JsonSerializerOptions { PropertyNameCaseInsensitive = true })!;
        }
    }
}
