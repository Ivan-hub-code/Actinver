﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WebDivisasActinver.Core.Interfaces;
using WebDivisasActinver.Core.Models;
using WebDivisasActinver.Infrastructure.Data;
using WebDivisasActinver.Infrastructure.Repositories;

namespace WebDivisasActinver.Infrastructure.UnitOfWork
{
    public class UnitOfWork : IUnitOfWork
    {
        private readonly ExchangeDbContext _context;
        public IGenericRepository<FavoriteCurrency> Favorites { get; }
        public IGenericRepository<Currency> Currencies { get; }

        public UnitOfWork(ExchangeDbContext context)
        {
            _context = context;
            Favorites = new GenericRepository<FavoriteCurrency>(_context);
            Currencies = new GenericRepository<Currency>(_context);
        }

        public async Task<int> CompleteAsync() => await _context.SaveChangesAsync();
        public void Dispose() => _context.Dispose();
    }
}
